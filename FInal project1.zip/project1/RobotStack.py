import sys
import math
def dpfun(b, n, k, dp):
    if b == 0: # if no robots are there, only 1 case
        return 1
    elif n == 0: # if no stack remaining, return 0
        return 0
    elif k == 1:
        return math.comb(n,b)
    elif dp[b][n][k] != -1:
        return dp[b][n][k]
    ways = 0
    for i in range(0,b + 1, k):
        # Here i is the number of robots that were put into stacks with k robots each.
        # so number of stacks used = i//k
        # Now for the remaining stacks, we will maximum assign k - 1 
        if i <= n * k:   
            remainingRobots = b - i
            stacksUsed = int(i/k)
            remainingStacks = n - stacksUsed
            ways += dpfun(remainingRobots, remainingStacks, k - 1, dp) * math.comb(n, stacksUsed)
    dp[b][n][k] = ways
    return dp[b][n][k]

def main():
    with open(sys.argv[1], "r") as inputFile:
        data = inputFile.readlines()
        for line in data:
            _input = list(map(int, line.split()))
            b, n, k = _input[0], _input[1], _input[2]
            dp = [ [ [-1 for k in range(k + 1)] for j in range(n + 1)] for i in range(b + 1)]
            ans = dpfun(b, n, k, dp)
            print("({},{},{}) = {}".format(b, n, k, ans))


if __name__ == "__main__":
    main()